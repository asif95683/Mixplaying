Mix Playing - ExoPlayer Android scaffold

- App Name: Mix Playing
- Features: local video picker, ExoPlayer playback, Banner+Interstitial+Rewarded ads integrated

AdMob IDs supplied:
App ID: ca-app-pub-3453134379248521~7324068230
Banner: ca-app-pub-3453134379248521/5412220762
Interstitial: ca-app-pub-3453134379248521/2786057428
Rewarded: ca-app-pub-3453134379248521/1758834642

Instructions:
1. Open in Android Studio and build.
2. Test ads with test device IDs before publishing.
3. Ensure you comply with Google Play policies for ads and content.
